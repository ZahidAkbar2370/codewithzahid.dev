<!DOCTYPE html>
<html>
<head>
    <title>Code With Zahid</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <h3>{{ $details['name'] }}</h3>
    <p>{{ $details['body'] }}</p>
<br><br>
    <center><a href="{{ $details['action'] }}" target="_blank"><button style="padding:20px">Visit Website</button></a></center>
<br>
    <p>Whatsapp: +92 308 1312527</p>
    <br><br>
    <p>Note: All Lectures Available On Website. if you have any Question feel free to Text me on Whatsapp.</p>
    <h4><b>Thanks You</b></h4>
</body>
</html>